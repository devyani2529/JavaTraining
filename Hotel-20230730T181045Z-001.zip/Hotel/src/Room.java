public class Room {
    private final int roomNumber;
    private boolean available;
    private Customer customer;

    public Room(int roomNumber) {
        this.roomNumber = roomNumber;
        this.available = true;
        this.customer = null;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
        this.available = customer == null;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public Customer getCustomer() {
        return customer;
    }
}
