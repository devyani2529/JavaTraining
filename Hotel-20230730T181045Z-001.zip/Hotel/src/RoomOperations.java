public interface RoomOperations {
    void bookRoom(Customer customer, int roomNumber) throws RoomNotAvailableException;

    void checkout(int roomNumber);
}
