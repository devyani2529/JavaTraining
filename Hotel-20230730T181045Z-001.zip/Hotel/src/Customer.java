
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Customer {
    private final String name;
    private int customerId;

    public Customer(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
}


//2.package

//3.package

//4.package


//Main Package



class HotelTest {
    public static void main(String[] args) {
        try {
            Hotel hotel = new Hotel();
            boolean s;
            for (int i = 1; i <= 5; i++) {
                hotel.addRoom(new Room(i));
            }

            Reception reception = new Reception(hotel);

            Customer customer1 = new Customer("John");
            Customer customer2 = new Customer("Alice");
            Customer customer3 = new Customer("Bob");

            Thread thread1 = new Thread(() -> {
                try {
                    reception.checkIn(customer1, 1);
                    Thread.sleep(2000);
                    reception.checkout(1);
                } catch (RoomNotAvailableException | InterruptedException e) {
                    e.printStackTrace();
                }
            });

            Thread thread2 = new Thread(() -> {
                try {
                    reception.checkIn(customer2, 2);
                    Thread.sleep(3000);
                    reception.checkout(2);
                } catch (RoomNotAvailableException | InterruptedException e) {
                    e.printStackTrace();
                }
            });

            Thread thread3 = new Thread(() -> {
                try {
                    reception.checkIn(customer3, 3);
                    Thread.sleep(1000);
                    reception.checkout(3);
                } catch (RoomNotAvailableException | InterruptedException e) {
                    e.printStackTrace();
                }
            });

            thread1.start();
            thread2.start();
            thread3.start();

            thread1.join();
            thread2.join();
            thread3.join();

            // Writing the hotel room status to a file
            try (PrintWriter writer = new PrintWriter(new FileWriter("hotel_status.txt"))) {
                for (Room room : hotel.getRooms()) {
                    writer.println("Room " + room.getRoomNumber() + " - " + (room.isAvailable() ? "Available" : "Occupied by " + room.getCustomer().getName()));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


