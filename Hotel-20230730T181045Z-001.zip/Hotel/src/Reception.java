public class Reception {
    private Hotel hotel;

    public Reception(Hotel hotel) {
        this.hotel = hotel;
    }

    public void checkIn(Customer customer, int roomNumber) throws RoomNotAvailableException {
        hotel.bookRoom(customer, roomNumber);
        System.out.println("Customer " + customer.getName() + " checked into Room " + roomNumber);
    }

    public void checkout(int roomNumber) {
        hotel.checkout(roomNumber);
        System.out.println("Room " + roomNumber + " checked out.");
    }
}
