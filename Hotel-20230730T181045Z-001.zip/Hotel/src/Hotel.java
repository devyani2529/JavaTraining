import java.util.ArrayList;
import java.util.List;

public class Hotel implements RoomOperations {
    private final List<Room> rooms;

    public Hotel() {
        rooms = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    @Override
    public void bookRoom(Customer customer, int roomNumber) throws RoomNotAvailableException {
        Room room = rooms.get(roomNumber - 1);
        if (room.isAvailable()) {
            room.setCustomer(customer);
        } else {
            throw new RoomNotAvailableException("Room " + roomNumber + " is not available.");
        }
    }

    @Override
    public void checkout(int roomNumber) {
        Room room = rooms.get(roomNumber - 1);
        room.setCustomer(null);
    }

    public Room[] getRooms() {
        return new Room[0];
    }
}
